# Delta Exchange India — $50 Paper/Test Bot V1

Safe starter bot. DEFAULT: DRY_RUN=true, so it does NOT place live orders.

Strategy:
- EMA 9 / EMA 21 trend filter
- RSI 14 confirmation
- 1% risk per trade ($0.50 on $50)
- 3% daily loss cap
- Maximum 3 trades/day
- Mandatory stop-loss / take-profit
- No martingale

IMPORTANT:
1. Do not put API secrets in chat.
2. Keep DRY_RUN=true until you have tested the bot.
3. Exchange contract specifications, authentication/signing, and endpoints can change. Verify current Delta Exchange India API docs before enabling live orders.
