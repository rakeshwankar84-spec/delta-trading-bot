import os, time, hmac, hashlib, json
from datetime import datetime, timezone
import requests
import pandas as pd
from dotenv import load_dotenv

load_dotenv()
BASE = os.getenv("DELTA_BASE_URL", "https://api.india.delta.exchange")
SYMBOL = os.getenv("SYMBOL", "BTCUSD")
TIMEFRAME = os.getenv("TIMEFRAME", "5m")
CAPITAL = float(os.getenv("CAPITAL_USD", "50"))
RISK = float(os.getenv("RISK_PER_TRADE", "0.01"))
DAILY_LIMIT = float(os.getenv("DAILY_LOSS_LIMIT", "0.03"))
MAX_TRADES = int(os.getenv("MAX_TRADES_PER_DAY", "3"))
DRY_RUN = os.getenv("DRY_RUN", "true").lower() == "true"
KEY = os.getenv("DELTA_API_KEY", "")
SECRET = os.getenv("DELTA_API_SECRET", "")

session = requests.Session()

def candles():
    # Verify the current endpoint/parameters in Delta's India API docs before use.
    url = f"{BASE}/v2/history/candles"
    params = {"symbol": SYMBOL, "resolution": TIMEFRAME, "limit": 100}
    r = session.get(url, params=params, timeout=15)
    r.raise_for_status()
    data = r.json()
    rows = data.get("result", data)
    if isinstance(rows, dict):
        rows = rows.get("data", [])
    df = pd.DataFrame(rows)
    if df.empty:
        raise RuntimeError("No candle data returned. Check symbol/timeframe/API endpoint.")
    # Try common field names
    rename = {}
    for a,b in [("close","close"),("Close","close"),("timestamp","timestamp"),
                ("time","timestamp"),("open","open"),("high","high"),("low","low")]:
        if a in df.columns: rename[a]=b
    df=df.rename(columns=rename)
    if "close" not in df.columns:
        raise RuntimeError(f"Unexpected candle schema: {list(df.columns)}")
    df["close"] = pd.to_numeric(df["close"], errors="coerce")
    return df.dropna(subset=["close"])

def signal(df):
    c=df["close"]
    df["ema9"]=c.ewm(span=9, adjust=False).mean()
    df["ema21"]=c.ewm(span=21, adjust=False).mean()
    d=c.diff()
    gain=d.clip(lower=0).rolling(14).mean()
    loss=(-d.clip(upper=0)).rolling(14).mean()
    rs=gain/loss.replace(0, pd.NA)
    df["rsi"]=100-(100/(1+rs))
    x=df.iloc[-1]
    if x.ema9 > x.ema21 and x.rsi > 55:
        return "buy", float(x.close)
    if x.ema9 < x.ema21 and x.rsi < 45:
        return "sell", float(x.close)
    return "none", float(x.close)

def log(msg):
    print(datetime.now(timezone.utc).isoformat(), msg, flush=True)

def main():
    log(f"START symbol={SYMBOL} capital=${CAPITAL} dry_run={DRY_RUN}")
    log("This V1 intentionally has no live order call. Add and verify current Delta order/authentication code only after testing.")
    trades=0
    while True:
        try:
            df=candles()
            side, price=signal(df)
            risk_usd=CAPITAL*RISK
            sl_pct=0.005  # 0.5% illustrative stop distance
            qty=max(0.0, risk_usd/(price*sl_pct))
            log(f"signal={side} price={price:.2f} risk=${risk_usd:.2f} indicative_qty={qty:.8f}")
            if side != "none":
                trades += 1
                if trades > MAX_TRADES:
                    log("Daily trade limit reached; waiting.")
                else:
                    log("PAPER SIGNAL ONLY — no order submitted.")
            time.sleep(300)
        except Exception as e:
            log(f"ERROR {type(e).__name__}: {e}")
            time.sleep(30)

if __name__=="__main__":
    main()
